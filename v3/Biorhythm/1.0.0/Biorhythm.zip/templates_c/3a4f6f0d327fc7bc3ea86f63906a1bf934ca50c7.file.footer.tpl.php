<?php /* Smarty version Smarty-3.0.6, created on 2011-10-05 14:23:35
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:961993114e8bf7e7cfb6c1-65317283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a4f6f0d327fc7bc3ea86f63906a1bf934ca50c7' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1317795728,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '961993114e8bf7e7cfb6c1-65317283',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>