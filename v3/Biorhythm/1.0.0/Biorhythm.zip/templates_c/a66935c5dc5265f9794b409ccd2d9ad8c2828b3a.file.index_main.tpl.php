<?php /* Smarty version Smarty-3.0.6, created on 2011-05-10 16:28:34
         compiled from "./templates/index_main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11135971614dc8f7327fe7d5-12271272%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a66935c5dc5265f9794b409ccd2d9ad8c2828b3a' => 
    array (
      0 => './templates/index_main.tpl',
      1 => 1304918481,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11135971614dc8f7327fe7d5-12271272',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php echo $_smarty_tpl->getVariable('template_top')->value;?>

<?php echo $_smarty_tpl->getVariable('template_contents')->value;?>

<?php echo $_smarty_tpl->getVariable('template_bottom')->value;?>
