<?php /* Smarty version Smarty-3.0.6, created on 2011-12-09 12:19:14
         compiled from "./templates/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3432692954e8bf7e7d51297-66706683%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '48ad11f68be179e1830edf3ce56b82b0712baeff' => 
    array (
      0 => './templates/main.tpl',
      1 => 1323404349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3432692954e8bf7e7d51297-66706683',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php echo $_smarty_tpl->getVariable('template_top')->value;?>

<?php echo $_smarty_tpl->getVariable('template_contents')->value;?>

<?php echo $_smarty_tpl->getVariable('template_bottom')->value;?>
