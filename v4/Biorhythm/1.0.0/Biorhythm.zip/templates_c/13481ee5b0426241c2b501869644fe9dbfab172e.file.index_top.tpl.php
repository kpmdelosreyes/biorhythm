<?php /* Smarty version Smarty-3.0.6, created on 2011-09-30 10:24:59
         compiled from "./templates/index_top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7270885174e85287b8d2eb3-34882449%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13481ee5b0426241c2b501869644fe9dbfab172e' => 
    array (
      0 => './templates/index_top.tpl',
      1 => 1317349400,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7270885174e85287b8d2eb3-34882449',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
  <title>Biorythm Plug-in </title>
  
  <link href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/<?php echo $_smarty_tpl->getVariable('aData')->value['pbd_template'];?>
.css" type="text/css" rel="stylesheet" />
  <link href="<?php echo $_smarty_tpl->getVariable('sPgLib')->value;?>
css/popup.calendar.css" type="text/css" rel="stylesheet" />
  
  <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('jquery')->value;?>
"></script>
  <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('emulation')->value;?>
"></script>
  <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
js/biorythm.front.js"></script>
  <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sPgLib')->value;?>
js/jquery.calendar.js"></script>
 </head>
 
 <body id="PLUGIN_Biorythm">
 
 <?php echo $_smarty_tpl->getVariable('sScriptCrossDomain')->value;?>
