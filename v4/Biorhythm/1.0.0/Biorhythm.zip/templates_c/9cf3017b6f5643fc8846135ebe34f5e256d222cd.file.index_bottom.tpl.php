<?php /* Smarty version Smarty-3.0.6, created on 2011-05-10 16:28:34
         compiled from "./templates/index_bottom.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15510235394dc8f7327b8d25-40202264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9cf3017b6f5643fc8846135ebe34f5e256d222cd' => 
    array (
      0 => './templates/index_bottom.tpl',
      1 => 1304918481,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15510235394dc8f7327b8d25-40202264',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>