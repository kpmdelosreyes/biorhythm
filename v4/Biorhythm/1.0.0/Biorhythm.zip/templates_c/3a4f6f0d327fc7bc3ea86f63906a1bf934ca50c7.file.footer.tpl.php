<?php /* Smarty version Smarty-3.0.6, created on 2011-12-09 12:19:14
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3910008814ee18c423f9e65-15885858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a4f6f0d327fc7bc3ea86f63906a1bf934ca50c7' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1323404349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3910008814ee18c423f9e65-15885858',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>